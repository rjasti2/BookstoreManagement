/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoremanagementsystem;

//import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;  
import java.io.BufferedWriter;
import java.io.FileReader;  
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


/**
 *
 * @author rachita
 */
public class BookStore {
    private String memberFirstName;
    private String memberLastName;
    private String productIDS;
    private String productQtyS;
    
     ArrayList<Product> productList = new ArrayList();
     ArrayList<Member> memberList = new ArrayList();
     int TotalBooksPurchased=0;
     int TotalDvdsPurchased=0;
     int TotalCdsPurchased=0;
     double TotalBooksPurchasedCost=0.00;
     double TotalDvdsPurchasedCost=0.00;
     double TotalCdsPurchasedCost=0.00;
     int newMemCount=0;
    
    public BookStore() {
    generateInventory();
    generateMembers();
    }
    
    private void generateInventory(){
        
    String line = "";  
    String deLimiter = ",";  
    String filePath = "C:/Users/rachi/Desktop";
    
   System.out.println("Welcome to Book Management System");
   System.out.println("");
   System.out.println("Enter csv File Name to Read Inventory");
   System.out.println("");
   System.out.println("");
   System.out.println("Example file name ::: ProductInventoryBookStore.csv");
   System.out.println("");
               // Scanner sc = new Scanner(System.in);
                //String fileName = sc.next();
                //sc.close();
                String fileName = "ProductInventoryBookStore.csv";
                String fileFullPath=filePath+"/"+fileName;
                System.out.println("file full path = "+ fileFullPath);
                
               
     try   
     {  
      //parsing a CSV file into BufferedReader class constructor  
    //  BufferedReader br = new BufferedReader(new FileReader("C:/Users/rachi/Desktop/ProductInventoryBookStore.csv")); 
       
     BufferedReader br = new BufferedReader(new FileReader(fileFullPath)); 
       while ((line = br.readLine()) != null)   //returns a Boolean value  
         {  
           String[] record = line.split(deLimiter);
           if(record[1].toUpperCase()== "BOOK"){
                        productList.add(new Books(Integer.parseInt(record[0]),record[1],record[2]
                              ,record[3],Integer.parseInt(record[4]),Double.parseDouble(record[5])));
           } else if(record[1].toUpperCase()== "DVD"){
                        productList.add(new DVD(Integer.parseInt(record[0]),record[1],record[2]
                              ,record[3],Integer.parseInt(record[4]),Double.parseDouble(record[5])));
           } else {
                        productList.add(new CD(Integer.parseInt(record[0]),record[1],record[2]
                              ,record[3],Integer.parseInt(record[4]),Double.parseDouble(record[5])));
           }
          }  
             // close the reader
             br.close();
     } 

       catch (IOException e)   
     {  
      e.printStackTrace();  
      }  

    // FileOutputStream fs = new FileOutputStream("C:/Users/rachi/Desktop/ProductInventoryBookStore.txt");
   //  PrintWriter outFS = new PrintWriter(fs);
     /**
     productList.add(new Books(1,"BOOK","Pride and Prejudice","Author1",80,9.00));
     productList.add(new Books(2,"BOOK","The Great Gatsby","Author1",80,9.00));
     productList.add(new Books(3,"BOOK","Wonder","Author1",80,9.00));
     productList.add(new Books(4,"BOOK","The Maze Runner","Author1",80,9.00));

      productList.add(new DVD(5,"DVD","Pride and Prejudice",80,9.00));
     productList.add(new DVD(6,"DVD","The Great Gatsby",80,9.00));
     productList.add(new DVD(7,"DVD","Wonder",80,9.00));
     productList.add(new DVD(8,"DVD","The Maze Runner",80,9.00));                          
      
     productList.add(new CD(9,"CD","Pride and Prejudice","Author1",80,9.00));
     productList.add(new CD(10,"CD","The Great Gatsby","Author1",80,9.00));
     productList.add(new CD(11,"CD","Wonder","Author1",80,9.00));
     productList.add(new CD(12,"CD","The Maze Runner","Author1",80,9.00));
     ***/
       System.out.println(productList.toString());
  
  
    }
    
    
    public void writeInventoryCsvFile(){
        
        try {
  
    // create a writer
    BufferedWriter writer = Files.newBufferedWriter(Paths.get("C:/Users/rachi/Desktop/ProductInventoryBookStore2.csv"));

    // write header record
    //writer.write("ID,Name,Country");
   // writer.newLine();

    // write all records
    for (Product s : productList) {
       // System.out.println("getclass="+s.getClass());
        writer.write(s.getProductID()+","+s.getProductType()+","
                        +s.getProductName()+","+s.getProductAuthor()
                +","+s.getProductQuantity()+","+s.getProductPrice()
          );
        writer.newLine();
    }

    //close the writer
    writer.close();

} catch (IOException ex) {
    ex.printStackTrace();
}
   System.out.println("Register Closed and Inventory written");   
}
     
    
      public void writeEndOfDayFile(){
        
        try {
  
    // create a writer
    BufferedWriter writer = Files.newBufferedWriter(Paths.get("C:/Users/rachi/Desktop/EndOfDayReportFile.txt"));

    // write header record
    writer.write(":::::::::::::: End of Day CloseOut Report :::::::::");
    writer.newLine();
    // write all records
    //System.out.println(productList.toString());
        writer.write("Total Books Purchased =" +TotalBooksPurchased);
        writer.newLine();
        writer.write("Total DVDs  Purchased =" +TotalDvdsPurchased);
        writer.newLine();
        writer.write("Total CDs   Purchased =" +TotalCdsPurchased);
        writer.newLine();
        writer.write("Total Books Purchased Cost=$" +TotalBooksPurchasedCost);
        writer.newLine();
        writer.write("Total DVDs  Purchased Cost=$" +TotalDvdsPurchasedCost);
        writer.newLine();
        writer.write("Total CDs   Purchased Cost=$" +TotalCdsPurchasedCost);
        writer.newLine();
        double TC=TotalBooksPurchasedCost+TotalDvdsPurchasedCost+TotalCdsPurchasedCost;
        writer.write("Total Inventory  Purchased Cost=$" +TC);
        writer.newLine();
        writer.write("New Members Added Count=" +newMemCount);
        writer.newLine();
        writer.write("******** End of Report ******");
        writer.newLine();

    //close the writer
    writer.close();

} catch (IOException ex) {
    ex.printStackTrace();
}
   System.out.println("Register Closed and Inventory Day Purchase Report written to file");   
}
      
    

    
    private void generateMembers(){
        
        memberList.add(new Member("John","Robert","R","N","VISA",1978.00));
        memberList.add(new Member("Phil","Buster","P","N","MASTER",20000.00));
        memberList.add(new Member("Sue","Martin","R","N","AMEX",1500.00));
        memberList.add(new Member("Anita","Mark","P","Y","DISCOVER",1000.00)); 
    
    }
    
  
        public  void inventoryOfproducts(){
           int TotalBookQuantity=0;
                  int TotalDVDQuantity=0;
                  int TotalCDQuantity=0;
                  
                  double TotalBookCost=0;
                  double TotalDVDCost=0;
                  double TotalCDCost=0;
            //  System.out.println(productList.toString());    
	  for (Product s : productList) {
              
            if(s.getProductType().toUpperCase().equals("BOOK")){                
               TotalBookQuantity=TotalBookQuantity + s.getProductQuantity();
               TotalBookCost=TotalBookCost + (s.getProductQuantity()*s.getProductPrice());
             //   System.out.println(TotalBookQuantity);
             //  System.out.println(TotalBookCost);
            }
            else if(s.getProductType().toUpperCase().equals("DVD")){
               // System.out.println(s.getProductType().toUpperCase());
               TotalDVDQuantity=TotalDVDQuantity + s.getProductQuantity();
               TotalDVDCost=TotalDVDCost + (s.getProductQuantity()*s.getProductPrice());
               //System.out.println(TotalDVDQuantity);
              // System.out.println(TotalDVDCost);
            }
                 else if(s.getProductType().toUpperCase().equals("CD")){
                
               TotalCDQuantity=TotalCDQuantity + s.getProductQuantity();
               TotalCDCost=TotalCDCost + (s.getProductQuantity()*s.getProductPrice());
            }
            
            }
            System.out.println("Total Books in Inventory= " + TotalBookQuantity);
            System.out.println("Total DVDs in Inventory= " + TotalDVDQuantity); 
            System.out.println("Total CDs in Inventory= " + TotalCDQuantity);
            int sumAllQty=TotalBookQuantity + TotalDVDQuantity + TotalCDQuantity;
            System.out.println("Total Inventory Quantity= " + sumAllQty); 
            
             System.out.println("Total Cost of Books in Inventory= $" + TotalBookCost);
            System.out.println("Total Cost of DVDs in Inventory= $" + TotalDVDCost); 
            System.out.println("Total Cost of CDs in Inventory= $" + TotalCDCost);
            double sumAllCost=TotalBookCost + TotalDVDCost + TotalCDCost;
            System.out.println("Total Cost of Inventory= $" + sumAllCost); 
      
      }
    
    public  void createNewMember(Scanner scan){
                System.out.println("What is your first name?");
                String fName = scan.next();
                
                System.out.println("What is your last name?");
                String lName = scan.next();
                
                System.out.println("What kind of member would you like to be. "
                        + "Enter R for Regular or P for Premium");
                
                String letter = scan.next();  
                System.out.println("letter= " +letter.toUpperCase());
                
                while(true){                    
                  if(letter.toUpperCase().equals("R") || letter.toUpperCase().equals("P")){
                                      break;                     
                }else {
                      System.out.println("What kind of member would you like to be. "
                        + "Enter R for Regular or P for Premium");
                      letter = scan.next();
                }       
                 }
                
                System.out.println("What is your prefered payment method?");
                System.out.println("Enter VISA or AMEX or MASTER or DISCOVER");
                
                String pType = scan.next();
                boolean existFlag=false;
                for(int i=0;i<memberList.size();i++){
                    if(memberList.get(i).getFirstName().toUpperCase().equals(fName.toUpperCase()) &&
                       memberList.get(i).getLastName().toUpperCase().equals(lName.toUpperCase())){
                        existFlag=true;
                        break;
                }
                }
                   if(existFlag){
                       
                       System.out.println("Member exist in the system");  
                   } else{
                      memberList.add(new Member(fName,lName,letter.toUpperCase(),"N",pType.toUpperCase(),0.00));
                      newMemCount++;
                      System.out.println("Member addded to the system");           
                   System.out.println("memberList= " + memberList.toString());
                   }
      
      }
    
  
         
          public void makePurchaseReceipt()
             {
                //    System.out.println("The following Book Titles Available::");
                 //   System.out.println("Product ID :Product Title");
                  //  for (Product s : productList) {
                  //  if(s.getProductType().toUpperCase().equals("BOOK") ){                
                  //     System.out.println(s.getProductID()+": "+s.getProductName());
           // }
          //  }                           
                                                         
                     //  System.out.println("Enter productID mentioned above"); 
                       int bookNo = Integer.parseInt(getProductID());
                       String bookTitle = "";
                       double bookPrice = 0.00; 
                         int existBookQuantity=0;
                         int TotalBookQuantity=0;
                     //  System.out.println("How many product ID = " +bookNo+ " books would you like to purchase?");                   
                         int bookQuantity = Integer.parseInt(getProductQty());
                         double booksPurchaseCost=0.00;
                    for (Product s : productList) {
                       if(s.getProductID() == bookNo && s.getProductType().toUpperCase().equals("BOOK")){  
                        bookPrice=s.getProductPrice();
                        bookTitle=s.getProductName();                      
                        booksPurchaseCost=bookPrice*bookQuantity;
                        existBookQuantity=s.getProductQuantity();
                        TotalBookQuantity=existBookQuantity - bookQuantity;
                       System.out.println("Before updating  BookQuantity:= " + s.getProductQuantity());
                       s.setProductQuantity(TotalBookQuantity);
                       System.out.println("After updating  BookQuantity:= " + s.getProductQuantity());
                                 }
                         }
                    //  System.out.println(""); 
                    //  System.out.println(""); 
                  //  System.out.println("The following CD Titles Available::");
                  //  System.out.println("Product ID :Product Title");
                  //  for (Product s : productList) {
                  //  if(s.getProductType().toUpperCase().equals("CD") ){                
                  //     System.out.println(s.getProductID()+": "+s.getProductName());
            //}
                       //  }                           
                                                         
                     //  System.out.println("Enter productID mentioned above"); 
                       int cdNo = Integer.parseInt(getProductID());
                       String cdTitle = "";
                       double cdPrice = 0.00; 
                         int existCDQuantity=0;
                         int TotalCDQuantity=0;
                      // System.out.println("How many product ID = " +cdNo+ " CDs would you like to purchase?");                   
                         int cdQuantity = Integer.parseInt(getProductQty());
                         double cdPurchaseCost=0.00;
                    for (Product s : productList) {
                       if(s.getProductID() == cdNo && s.getProductType().toUpperCase().equals("CD")){  
                        cdPrice=s.getProductPrice();
                        cdTitle=s.getProductName();                      
                        cdPurchaseCost=cdPrice*cdQuantity;
                        existCDQuantity=s.getProductQuantity();
                        TotalCDQuantity=existCDQuantity - cdQuantity;
                       System.out.println("Before updating  CDQuantity:= " + s.getProductQuantity());
                       s.setProductQuantity(TotalCDQuantity);
                       System.out.println("After updating  CDQuantity:= " + s.getProductQuantity());
                                 }
                         }               
             
                     //System.out.println(""); 
                     // System.out.println(""); 
                    //  System.out.println("The following DVD Titles Available::");
                //    System.out.println("Product ID :Product Title");
                 //   for (Product s : productList) {
                 //   if(s.getProductType().toUpperCase().equals("DVD") ){                
                  //     System.out.println(s.getProductID()+": "+s.getProductName());
          //  }
                     //    }                            
                                                         
                      // System.out.println("Enter productID mentioned above"); 
                       int dvdNo = Integer.parseInt(getProductID());
                       String dvdTitle = "";
                       double dvdPrice = 0.00; 
                         int existDVDQuantity=0;
                         int TotalDVDQuantity=0;
                      // System.out.println("How many product ID = " +dvdNo+ " DVDs would you like to purchase?");                   
                         int dvdQuantity = Integer.parseInt(getProductQty());
                         double dvdPurchaseCost=0.00;
                    for (Product s : productList) {
                       if(s.getProductID() == dvdNo && s.getProductType().toUpperCase().equals("DVD")){  
                        dvdPrice=s.getProductPrice();
                        dvdTitle=s.getProductName();                      
                        dvdPurchaseCost=dvdPrice*dvdQuantity;
                        existDVDQuantity=s.getProductQuantity();
                        TotalDVDQuantity=existDVDQuantity - dvdQuantity;
                       System.out.println("Before updating  DVDQuantity:= " + s.getProductQuantity());
                       s.setProductQuantity(TotalDVDQuantity);
                       System.out.println("After updating  DVDQuantity:= " + s.getProductQuantity());
                                 }
                         }     
                                  
                    // System.out.println("What is your first name?");
                      String  fName = getMemberFirstName();
                    //   System.out.println("What is your last name?");
                       String lName = getMemberLastName();
                         
                         System.out.println("Total booksPurchaseCost =$"+booksPurchaseCost);
                         System.out.println("Total cdPurchaseCost =$"+cdPurchaseCost);
                         System.out.println("Total dvdPurchaseCost =$"+dvdPurchaseCost);
                         
                         TotalBooksPurchased=TotalBooksPurchased+bookQuantity;
                         TotalCdsPurchased=TotalCdsPurchased+cdQuantity;
                         TotalDvdsPurchased=TotalDvdsPurchased+dvdQuantity;
                         
                         TotalBooksPurchasedCost=TotalBooksPurchasedCost+booksPurchaseCost;
                         TotalCdsPurchasedCost=TotalCdsPurchasedCost+cdPurchaseCost;
                         TotalDvdsPurchasedCost=TotalDvdsPurchasedCost+dvdPurchaseCost;
                         
                         double TCost=booksPurchaseCost+dvdPurchaseCost+cdPurchaseCost;
                          double roundTcost=(Math.round(TCost * 100))/100;
                         System.out.println("Total roundTcost  =$"+roundTcost);
                       //   System.out.println("Enter Payment Tendered ");
                        //  double paymentTend= scan.nextDouble();
                   
                          //if (roundTcost <= paymentTend){
                           System.out.println("Payment Tendered and Receipt issued");
                          // }else {
                          //    System.out.println("Payment Tendered is less than purchase cost");
                         // }
                          
                         // Add Total purchase Cost to memeber.
        
                           
                for(int i=0;i<memberList.size();i++){
                    if(memberList.get(i).getFirstName().toUpperCase().equals(fName.toUpperCase()) &&
                        memberList.get(i).getLastName().toUpperCase().equals(lName.toUpperCase())){
                        System.out.println("Purchase Cost =$"+memberList.get(i).getPurchaseAmount());
                        double ExistPurchaseAmount=memberList.get(i).getPurchaseAmount();
                        memberList.get(i).setPurchaseAmount(ExistPurchaseAmount+TCost);
                        System.out.println("Total Purchase Cost after added cost to member=$"+memberList.get(i).getPurchaseAmount());
                         System.out.println("memberList= " + memberList.get(i).toString());
                         
                        break;
                }
                }}  
          /***
          
          public void makePurchaseReceipt(Scanner scan)
             {
                    System.out.println("The following Book Titles Available::");
                    System.out.println("Product ID :Product Title");
                    for (Product s : productList) {
                    if(s.getProductType().toUpperCase().equals("BOOK") ){                
                       System.out.println(s.getProductID()+": "+s.getProductName());
            }
            }                           
                                                         
                       System.out.println("Enter productID mentioned above"); 
                       int bookNo = scan.nextInt();
                       String bookTitle = "";
                       double bookPrice = 0.00; 
                         int existBookQuantity=0;
                         int TotalBookQuantity=0;
                       System.out.println("How many product ID = " +bookNo+ " books would you like to purchase?");                   
                         int bookQuantity = scan.nextInt();
                         double booksPurchaseCost=0.00;
                    for (Product s : productList) {
                       if(s.getProductID() == bookNo && s.getProductType().toUpperCase().equals("BOOK")){  
                        bookPrice=s.getProductPrice();
                        bookTitle=s.getProductName();                      
                        booksPurchaseCost=bookPrice*bookQuantity;
                        existBookQuantity=s.getProductQuantity();
                        TotalBookQuantity=existBookQuantity - bookQuantity;
                       System.out.println("Before updating  BookQuantity:= " + s.getProductQuantity());
                       s.setProductQuantity(TotalBookQuantity);
                       System.out.println("After updating  BookQuantity:= " + s.getProductQuantity());
                                 }
                         }
                      System.out.println(""); 
                      System.out.println(""); 
                    System.out.println("The following CD Titles Available::");
                    System.out.println("Product ID :Product Title");
                    for (Product s : productList) {
                    if(s.getProductType().toUpperCase().equals("CD") ){                
                       System.out.println(s.getProductID()+": "+s.getProductName());
            }
                         }                           
                                                         
                       System.out.println("Enter productID mentioned above"); 
                       int cdNo = scan.nextInt();
                       String cdTitle = "";
                       double cdPrice = 0.00; 
                         int existCDQuantity=0;
                         int TotalCDQuantity=0;
                       System.out.println("How many product ID = " +cdNo+ " CDs would you like to purchase?");                   
                         int cdQuantity = scan.nextInt();
                         double cdPurchaseCost=0.00;
                    for (Product s : productList) {
                       if(s.getProductID() == cdNo && s.getProductType().toUpperCase().equals("CD")){  
                        cdPrice=s.getProductPrice();
                        cdTitle=s.getProductName();                      
                        cdPurchaseCost=cdPrice*cdQuantity;
                        existCDQuantity=s.getProductQuantity();
                        TotalCDQuantity=existCDQuantity - cdQuantity;
                       System.out.println("Before updating  CDQuantity:= " + s.getProductQuantity());
                       s.setProductQuantity(TotalCDQuantity);
                       System.out.println("After updating  CDQuantity:= " + s.getProductQuantity());
                                 }
                         }               
             
                     System.out.println(""); 
                      System.out.println(""); 
                      System.out.println("The following DVD Titles Available::");
                    System.out.println("Product ID :Product Title");
                    for (Product s : productList) {
                    if(s.getProductType().toUpperCase().equals("DVD") ){                
                       System.out.println(s.getProductID()+": "+s.getProductName());
            }
                         }                            
                                                         
                       System.out.println("Enter productID mentioned above"); 
                       int dvdNo = scan.nextInt();
                       String dvdTitle = "";
                       double dvdPrice = 0.00; 
                         int existDVDQuantity=0;
                         int TotalDVDQuantity=0;
                       System.out.println("How many product ID = " +dvdNo+ " DVDs would you like to purchase?");                   
                         int dvdQuantity = scan.nextInt();
                         double dvdPurchaseCost=0.00;
                    for (Product s : productList) {
                       if(s.getProductID() == dvdNo && s.getProductType().toUpperCase().equals("DVD")){  
                        dvdPrice=s.getProductPrice();
                        dvdTitle=s.getProductName();                      
                        dvdPurchaseCost=dvdPrice*dvdQuantity;
                        existDVDQuantity=s.getProductQuantity();
                        TotalDVDQuantity=existDVDQuantity - dvdQuantity;
                       System.out.println("Before updating  DVDQuantity:= " + s.getProductQuantity());
                       s.setProductQuantity(TotalDVDQuantity);
                       System.out.println("After updating  DVDQuantity:= " + s.getProductQuantity());
                                 }
                         }     
                                  
                     System.out.println("What is your first name?");
                      String  fName = scan.next();
                       System.out.println("What is your last name?");
                       String lName = scan.next();
                         
                         System.out.println("Total booksPurchaseCost =$"+booksPurchaseCost);
                         System.out.println("Total cdPurchaseCost =$"+cdPurchaseCost);
                         System.out.println("Total dvdPurchaseCost =$"+dvdPurchaseCost);
                         
                         TotalBooksPurchased=TotalBooksPurchased+bookQuantity;
                         TotalCdsPurchased=TotalCdsPurchased+cdQuantity;
                         TotalDvdsPurchased=TotalDvdsPurchased+dvdQuantity;
                         
                         TotalBooksPurchasedCost=TotalBooksPurchasedCost+booksPurchaseCost;
                         TotalCdsPurchasedCost=TotalCdsPurchasedCost+cdPurchaseCost;
                         TotalDvdsPurchasedCost=TotalDvdsPurchasedCost+dvdPurchaseCost;
                         
                         double TCost=booksPurchaseCost+dvdPurchaseCost+cdPurchaseCost;
                          double roundTcost=(Math.round(TCost * 100))/100;
                         System.out.println("Total roundTcost  =$"+roundTcost);
                          System.out.println("Enter Payment Tendered ");
                          double paymentTend= scan.nextDouble();
                   
                          if (roundTcost <= paymentTend){
                           System.out.println("Payment Tendered and Receipt issued");
                           }else {
                              System.out.println("Payment Tendered is less than purchase cost");
                          }
                          
                         // Add Total purchase Cost to memeber.
        
                           
                for(int i=0;i<memberList.size();i++){
                    if(memberList.get(i).getFirstName().toUpperCase().equals(fName.toUpperCase()) &&
                        memberList.get(i).getLastName().toUpperCase().equals(lName.toUpperCase())){
                        System.out.println("Purchase Cost =$"+memberList.get(i).getPurchaseAmount());
                        double ExistPurchaseAmount=memberList.get(i).getPurchaseAmount();
                        memberList.get(i).setPurchaseAmount(ExistPurchaseAmount+TCost);
                        System.out.println("Total Purchase Cost after added cost to member=$"+memberList.get(i).getPurchaseAmount());
                         System.out.println("memberList= " + memberList.get(i).toString());
                         
                        break;
                }
                }}  
          
          ***/
          
          
                public String getMemberFirstName() {
        return memberFirstName;
    }
                
                              public String getMemberLastName() {
        return memberLastName;
    }
      
      public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
    }
      
            public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
    }
            
      
      public String getProductID() {
        return productIDS;
    }

    public void setProductID(String productID) {
        this.productIDS = productID;
    }
    
          public String getProductQty() {
        return productQtyS;
    }

    public void setProductQty(String productQty) {
        this.productQtyS = productQty;
    }
    
    
}
