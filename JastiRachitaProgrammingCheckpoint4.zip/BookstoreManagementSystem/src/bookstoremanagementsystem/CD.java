/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoremanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author rachita
 */
public class CD extends Product {
    private static int nextBookID=1;
    private int productID;
    private String productType;
    private String productAuthor;
    private String productName;
    private double productPrice;
    private int productQuantity;
  
   
public CD (int productID,String productType,String productName,String productAuthor,int productQuantity, double productPrice){
      super (productID,productType,productName,productAuthor,productQuantity,productPrice);
   
}
 
     

}
