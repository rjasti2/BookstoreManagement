/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoremanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author rachita
 */
public class Member {
  
    private String firstName;
    private String lastName;
    private String memberType;
    private String paymentType;
    private String memberFeeDue;
    private double purchaseAmount;
    

    public  Member(){};
    
        public Member (String fName, String lName,String mType,String mFeeDue,
                String pType,double pAmount ){
        this.firstName = fName;
        this.lastName = lName;
        this.memberType = mType;
        this.memberFeeDue = mFeeDue;
        this.paymentType = pType;
        this.purchaseAmount = pAmount;
}
    
    /**
     * Determines what a person's first name is
     * @return the student's first name
     */
    public String getFirstName(){
        return firstName;
    }
    /**
     * Determines what a person's last name is
     * @return the student's last name
     */
    public String getLastName(){
        return lastName;
    }
    /**
     * Determines what the person's ID is
     * @return the student's first name
     */
    public String getMemberFeeDue(){
        return memberFeeDue;
    }
    
     public String getPaymentType(){
        return paymentType;
    }
          public double getPurchaseAmount(){
        return purchaseAmount;
    }
          
     public void setFirstName(String firstName){
        this.firstName=firstName;
    }
   public void setLastName(String lastName){
        this.lastName=lastName;
    }  
    
     public void setMemberFeeDue(String memberFeeDue){
        this.memberFeeDue=memberFeeDue;
    }  
    
     
         public void setPaymentType(String paymentType){
        this.paymentType=paymentType;
    }  
         
    public void setPurchaseAmount(double purchaseAmount){
       this.purchaseAmount=purchaseAmount;
    }  
    

    @Override
    public String toString() {
        return "Member{" + "firstName=" + firstName + ", lastName=" + lastName 
                + ", memberType=" + memberType + ", memberFee=" + memberFeeDue 
                + ", paymentType=" + paymentType 
                + ", purchaseAmount=" + purchaseAmount 
                + '}';
    }
    
     public  void createNewMember(ArrayList<Member> memberList,Scanner scan){
                System.out.println("What is your first name?");
                String fName = scan.next();
                
                System.out.println("What is your last name?");
                String lName = scan.next();
                
                System.out.println("What kind of member would you like to be. "
                        + "Enter R for Regular or P for Premium");
                
                String letter = scan.next();  
                System.out.println("letter= " +letter.toUpperCase());
                
                while(true){                    
                  if(letter.toUpperCase().equals("R") || letter.toUpperCase().equals("P")){
                                      break;                     
                }else {
                      System.out.println("What kind of member would you like to be. "
                        + "Enter R for Regular or P for Premium");
                      letter = scan.next();
                }       
                 }
                
                System.out.println("What is your prefered payment method?");
                System.out.println("Enter VISA or AMEX or MASTER or DISCOVER");
                
                String pType = scan.next();
                boolean existFlag=false;
                for(int i=0;i<memberList.size();i++){
                    if(memberList.get(i).getFirstName().toUpperCase().equals(fName.toUpperCase()) &&
                       memberList.get(i).getLastName().toUpperCase().equals(lName.toUpperCase())){
                        existFlag=true;
                        break;
                }
                }
                   if(existFlag){
                       
                       System.out.println("Member exist in the system");  
                   } else{
                        memberList.add(new Member(fName,lName,letter.toUpperCase(),"N",pType.toUpperCase(),0.00));
                   System.out.println("Member addded to the system");           
                   System.out.println("memberList= " + memberList.toString());
                   }
      
      }
    

}


