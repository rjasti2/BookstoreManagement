/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoremanagementsystem;

import java.util.ArrayList;

/**
 *
 * @author rachita
 */
public class Books extends Product {
    private static int nextBookID=1;
    private int productID;
    private String productType;
    private String productAuthor;
    private String productName;
    private double productPrice;
    private int productQuantity;
  
   
public Books (int productID,String productType,String productName,String productAuthor,int productQuantity, double productPrice){
      super (productID,productType,productName,productAuthor,productQuantity,productPrice);
     // this.productAuthor=productAuthor;
   
}
 
      
       
     
    private static void incrementNextBookID() {
     nextBookID++;
 }
    
    public void printBookCount(int bookQuantity){
        System.out.println("The number of books the store holds: "+ bookQuantity);
    }
  /****  
@Override
    public String toString() {
          return "Product{" +
                   "productID=" + productID + 
                  ", productType=" + productType + 
                   ", productName=" + productName + 
                  ", productAuthor=" + productAuthor +
                   ", productQuantity=" + productQuantity +
                   ", productPrice=" + productPrice +                  
                  + '}';
    
    }****/
 
            }
    
    

