/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoremanagementsystem;

import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author rachita
 */
public class BookstoreManagementSystem {
    private String memberName;
    private String productID;

    

    public static void main(String[] args) {
       
      
      //  BookstoreManagementSystem myModelB = new BookstoreManagementSystem();
        WelcomeFrame myWelcomeFrame = new WelcomeFrame();        
         myWelcomeFrame.setVisible(true);
        
     //   BookStore myModel = new BookStore();
      //  StartFrame myStartFrame = new StartFrame(myModel);
      //  myStartFrame.setVisible(true);
        
/****
	int count = 6;
	        
       // BookStore inventory = new BookStore();     
        Scanner scan = new Scanner(System.in);
               
		int menu = 0;
		System.out.println("Book Store Management System");
		System.out.println();
		System.out.println("1. Inventory of all Products");
		System.out.println("2. Create a new member");
                System.out.println("3. Make a purchase, Checkout and Add cost to member");
                System.out.println("4. End of day closeOut");
		System.out.println("5. Exit");
		boolean quit = false;
		do {
		
		System.out.print("Please enter your choice: ");
		menu = scan.nextInt();
		System.out.println();
                
                
		switch (menu) {
		case 1:                    
                    System.out.println("Products in Inventory ");
                   
                   // inventory.inventoryOfproducts();           
                    break;
		case 2:
                   
                   
                    //inventory.createNewMember(scan);            
		    break;                        
		case 3:                    
                    //inventory.makePurchaseReceipt(scan);                
                    break; 
              	case 4:                    
                    //inventory.writeInventoryCsvFile();
                    //inventory.writeEndOfDayFile();
                    break; 
                case 5:
			quit = true;
			break;
			default:
			System.out.println("Invalid Entry!");
			}
		} while (!quit);
                ****/
           
	}
   
   
}

        
        
    
    

