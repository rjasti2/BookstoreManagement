/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoremanagementsystem;

//import java.util.ArrayList;

/**
 *
 * @author rachita
 */
public class PremiumMember extends Member{
    private String firstName;
    private String lastName;
    private String memberType;
    private String paymentType;
    private String memberFeeDue;
    private final double premiumMemberCost =15.00;
    private double purchaseAmount;
    
    
        public PremiumMember (String firstName, String lastName,String memberType,String paymentType,
                String memberFeeDue,double purchaseAmount ){
            super(firstName,lastName,memberType,paymentType,memberFeeDue,purchaseAmount);
    
}
    
   @Override
    public String getFirstName(){
        return firstName;
    }
  @Override
    public String getLastName(){
        return lastName;
    }
    @Override
    public String getMemberFeeDue(){
        return memberFeeDue;
    }
    @Override
     public String getPaymentType(){
        return paymentType;
    }
     @Override
          public double getPurchaseAmount(){
        return purchaseAmount;
    }
      @Override    
     public void setFirstName(String firstName){
        this.firstName=firstName;
    }
     @Override
   public void setLastName(String lastName){
        this.lastName=lastName;
    }  
    @Override
     public void setMemberFeeDue(String memberFeeDue){
        this.memberFeeDue=memberFeeDue;
    }  
    
     @Override
         public void setPaymentType(String paymentType){
        this.paymentType=paymentType;
    }  
      @Override   
    public void setPurchaseAmount(double purchaseAmount){
       this.purchaseAmount=purchaseAmount;
    }  
    
     public double getPremiumMemberCost(){
        return premiumMemberCost;
    }
     

    @Override
    public String toString() {
        return "Member{" + "firstName=" + firstName + ", lastName=" + lastName 
                + ", memberType=" + memberType + ", memberFee=" + memberFeeDue 
                + ", paymentType=" + paymentType 
                + ", purchaseAmount=" + purchaseAmount 
                + '}';
    }
    
     }
     
 

